// --- CONFIGURATION & STATE ---
let currentRole = 'patient';
// Demo Credentials as per Slide 216
const CREDENTIALS = {
    patient: { id: "P123", pass: "patient" },
    doctor: { id: "D123", pass: "doctor" }
};

// --- 1. ROLE SWITCHING LOGIC (Slide 216) ---
function switchRole(role) {
    currentRole = role;
    
    // UI Updates
    document.getElementById('patTab').classList.toggle('active', role === 'patient');
    document.getElementById('docTab').classList.toggle('active', role === 'doctor');
    
    document.getElementById('loginTitle').innerText = role === 'doctor' ? 'Doctor Login' : 'Patient Login';
    document.getElementById('idLabel').innerText = role === 'doctor' ? 'Doctor ID' : 'Patient ID';
    document.getElementById('userId').placeholder = role === 'doctor' ? 'Enter Doctor ID' : 'Enter Patient ID';
    
    // Clear form on switch
    document.getElementById('loginForm').reset();
}

// --- 2. LOGIN AUTHENTICATION (Slide 216) ---
if (document.getElementById('loginForm')) {
    document.getElementById('loginForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const idInput = document.getElementById('userId').value;
        const passInput = document.getElementById('password').value;

        // Validate against Slide 216 credentials
        if (idInput === CREDENTIALS[currentRole].id && passInput === CREDENTIALS[currentRole].pass) {
            window.location.href = currentRole === 'doctor' ? 'doctor-dashboard.html' : 'patient-dashboard.html';
        } else {
            alert("Invalid ID or Password. Please use the demo credentials provided below the form.");
        }
    });
}

// --- 3. ROBOT CONTROL (Slide 148 / 205) ---
// Bidirectional communication via HTTP commands to ESP8266 [cite: 148, 205]
function robotMove(command) {
    console.log(`Sending HTTP Command to NodeMCU: ${command.toUpperCase()}`);
    
    /* Architecture Implementation[cite: 145, 167]:
    fetch(`http://[ROBOT_IP]/control?move=${command}`)
        .then(response => console.log("Robot status: Command Received"))
        .catch(err => console.error("Connection lost to DocBot"));
    */
}

// --- 4. VITALS DATABASE SYNC ---

function loadPatients() {
    console.log("Fetching real data from PatientServlet...");

    fetch('PatientServlet') 
        .then(response => {
            if (!response.ok) throw new Error('Servlet error');
            return response.text();
        })
        .then(data => {
            const tableBody = document.getElementById('vitalsBody');
            if (tableBody) {
                // This puts Jeni (and everyone else in the DB) into the table
                tableBody.innerHTML = data;
                console.log("Table updated from Database!");
            }
        })
        .catch(error => console.error('Fetch error:', error));
}

// --- 5. INITIALIZATION & REFRESH ---

document.addEventListener('DOMContentLoaded', function() {
    // 1. Load the data immediately on open
    loadPatients();
    
    // 2. REFRESH from database every 5 seconds (Instead of the old updateVitals)
    setInterval(loadPatients, 5000); 
});

// --- 5. MODAL & DATA MANAGEMENT (NEW) ---

// Opens the "Add Patient Entry" popup
function openModal() {
    const modal = document.getElementById('addModal');
    if (modal) {
        modal.style.display = 'flex'; // Shows the modal over the dashboard
    }
}

// Closes the popup and resets fields
function closeModal() {
    const modal = document.getElementById('addModal');
    if (modal) {
        modal.style.display = 'none'; // Hides the modal
        // Clear inputs for next use
        document.getElementById('newName').value = '';
        document.getElementById('newID').value = '';
        document.getElementById('newRoom').value = '';
        document.getElementById('newTemp').value = '';
    }
}

// Adds a new patient to the simulation array
function addPatient() {
    const name = document.getElementById('newName').value;
    const id = document.getElementById('newID').value;
    const room = document.getElementById('newRoom').value;
    const temp = document.getElementById('newTemp').value;

    if (name && id && room && temp) {
        // Pushes new data into your existing 'patients' array
        patients.push({
            name: name,
            id: id,
            room: room,
            temp: parseFloat(temp).toFixed(1),
            hr: 75,   // Default starting values
            spo2: 98
        });

        updateVitals(); // Refreshes the table immediately
        closeModal();   // Closes the popup
    } else {
        alert("Please fill in all fields before saving.");
    }
}

function showSection(sectionId) {
    // 1. Hide all sections
    const sections = document.querySelectorAll('.tab-content');
    sections.forEach(sec => sec.style.display = 'none');

    // 2. Show the clicked section
    document.getElementById(sectionId).style.display = 'block';

    // 3. Update the active class on sidebar links
    const links = document.querySelectorAll('.sidebar-link');
    links.forEach(link => link.classList.remove('active'));
    event.currentTarget.classList.add('active');
}



function switchTab(event, tabId) {
    event.preventDefault();

    // 1. Hide ALL tab-page containers
    const pages = document.querySelectorAll('.tab-page');
    pages.forEach(page => {
        page.style.display = 'none';
    });

    // 2. Show the specific container you clicked
    document.getElementById(tabId).style.display = 'block';

    // 3. Update Sidebar styles
    const links = document.querySelectorAll('.sidebar-link');
    links.forEach(link => link.classList.remove('active'));
    event.currentTarget.classList.add('active');

    // 4. If switching to message, load the list
    if(tabId === 'message-view') {
        loadPatientChatList();
    }
}

// Function to populate the chat sidebar
function loadPatientChatList() {
    const list = document.getElementById('patientChatList');
    // Example data based on your screenshot
    const patients = [
        { name: "Jeevanantham", id: "44785", room: "106" },
        { name: "Abi", id: "57963", room: "602" }
    ];

    list.innerHTML = patients.map(p => `
        <div class="chat-item" onclick="startCall('${p.name}')" style="padding: 15px; border-bottom: 1px solid #eee; cursor: pointer;">
            <strong>${p.name}</strong><br>
            <small>Room ${p.room} • ID: ${p.id}</small>
        </div>
    `).join('');
}

function startCall(name) {
    document.getElementById('callHeader').innerText = "Live Video: " + name;
    document.getElementById('videoContainer').querySelector('i').style.display = 'none';
    document.getElementById('callStatusText').style.display = 'block';
    document.getElementById('callControls').style.display = 'block';
}

// This replaces window.onload to ensure it runs without conflict
document.addEventListener('DOMContentLoaded', function() {
    console.log("Dashboard loaded - triggered loadPatients");
    loadPatients();
});

function loadPatients() {
    // This will appear in your console so you know it started
    console.log("Fetching data from PatientServlet...");

    fetch('PatientServlet') 
        .then(response => {
            if (!response.ok) {
                throw new Error('Servlet not found or error');
            }
            return response.text();
        })
        .then(data => {
            const tableBody = document.getElementById('vitalsBody');
            if (tableBody) {
                // This injects "Jeni" and any other rows from the DB
                tableBody.innerHTML = data;
                console.log("Table updated successfully!");
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
        });
}