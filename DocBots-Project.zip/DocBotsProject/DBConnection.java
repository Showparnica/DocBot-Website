import java.sql.*;

public class DBConnection {
    public static Connection getConnection() {
        Connection con = null;
        try {
            // This matches the driver we put in your lib folder
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Connects to your docbots_db in XAMPP
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/docbots_db", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
}