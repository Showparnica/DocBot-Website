import java.io.*;
import javax.servlet.*;        // Use javax, NOT jakarta
import javax.servlet.http.*;   // Use javax, NOT jakarta
import java.sql.*;

public class PatientServlet extends HttpServlet {
    // Handling the "Save" button (POST)
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
    // 1. Capture the ID from the form
    String id = request.getParameter("id"); 
    String name = request.getParameter("name");
    String room = request.getParameter("room");
    String temp = request.getParameter("temp");

    try {
        Connection con = DBConnection.getConnection();
        // 2. Add 'id' back into the SQL query
        String sql = "INSERT INTO patients (id, name, room, temp, hr, status) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        
        ps.setString(1, id);    // Sets "P123"
        ps.setString(2, name);
        ps.setString(3, room);
        ps.setString(4, temp);
        ps.setString(5, "81 bpm"); 
        ps.setString(6, "STABLE"); 
        
        ps.executeUpdate();
        response.sendRedirect("doctor-dashboard.html"); 
    } catch (Exception e) { 
        e.printStackTrace(); 
    }
}
    // Handling the table display (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try {
            Connection con = DBConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM patients");
            while(rs.next()) {
                out.println("<tr><td>" + rs.getString("name") + "</td><td>" + rs.getString("id") + "</td><td>" + rs.getString("room") + "</td><td>" + rs.getString("temp") + "</td><td>80 bpm</td><td><span class='badge'>" + rs.getString("status") + "</span></td></tr>");
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}